client = genai.Client()
interaction = client.interactions.create(
    model="gemini-3.8-flash",
    input='''Please generate a Chinese lesson in TBCL Level-4 with Pinyin after each sentence, 
             quote each Level-4 word,
             followed by an exam of 10 words in TBCL Level-4 from the lesson text.''',
    response_format={
        "type": "text",
        "mime_type": "application/json",
        "schema": Exam.model_json_schema()
    })
exam = Exam.model_validate_json(interaction.output_text)
