from google import genai
from pydantic import BaseModel, Field
from typing import List
class Word(BaseModel):
    word: str = Field(description="Word form.")
    pinyin: str = Field(description="Pronunciation of the word.")
class Exam(BaseModel):
    exam_name: str = Field(description="The name of the exam.")
    words: List[Word]
client = genai.Client(api_key="AIzaSyAYom5TEkOZL6ghJqiSjFluj7AfMez-BDQ")
interaction = client.interactions.create(
    model="gemini-3.8-flash",
    input="Please generate a Chinese exam of 10 words in TBCL Level-4.",
    response_format={
        "type": "text",
        "mime_type": "application/json",
        "schema": Exam.model_json_schema()
    })
exam = Exam.model_validate_json(interaction.output_text)
for word in exam.words:
    print(word.word, word.pinyin)
from django.http import HttpResponse
from django.shortcuts import render
def home(request):
    return render(request, "exam.htm",{"exam": exam})
def result(request):
    return HttpResponse('''恭喜你通過了這一課，請點擊此連結前往<a href=4>TBCL第4級</a>的課文！<br>或返回上頁另生成一課～''')#request.POST["word_1"])